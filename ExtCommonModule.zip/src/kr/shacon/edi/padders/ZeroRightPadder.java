package kr.shacon.edi.padders;

public class ZeroRightPadder extends AbstractRightPadder {

  public ZeroRightPadder() {
    super('0');
  }

}
