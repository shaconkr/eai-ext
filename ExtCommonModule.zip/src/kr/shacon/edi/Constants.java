package kr.shacon.edi;

class Constants {

  static final String SHACON_KR_XSD = "http://shacon.kr/xsd";
  static final String W3C_SCHEMA = "http://www.w3.org/2001/XMLSchema";

  private Constants() {
  }

}
