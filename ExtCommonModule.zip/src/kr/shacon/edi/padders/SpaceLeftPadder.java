package kr.shacon.edi.padders;

public class SpaceLeftPadder extends AbstractLeftPadder {

  public SpaceLeftPadder() {
    super(' ');
  }

}
