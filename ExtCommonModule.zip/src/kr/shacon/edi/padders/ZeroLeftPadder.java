package kr.shacon.edi.padders;

public class ZeroLeftPadder extends AbstractLeftPadder {

  public ZeroLeftPadder() {
    super('0');
  }

}
