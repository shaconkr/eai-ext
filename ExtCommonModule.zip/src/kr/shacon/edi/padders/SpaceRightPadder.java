package kr.shacon.edi.padders;

public class SpaceRightPadder extends AbstractRightPadder {

  public SpaceRightPadder() {
    super(' ');
  }

}
